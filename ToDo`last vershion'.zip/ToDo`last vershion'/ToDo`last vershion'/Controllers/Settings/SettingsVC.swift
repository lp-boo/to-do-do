//
//  SettingsVC.swift
//  ToDo`last vershion'
//
//  Created by Moby on 16.01.22.
//

import UIKit

class SettingsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Settings"

    }


   

}
